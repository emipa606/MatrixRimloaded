﻿namespace MatrixRimloaded
{
    using RimWorld;
    using RimWorld.Planet;
    using Verse;
    using Ability = VFECore.Abilities.Ability;

    public class Ability_JumpOfFaith : Ability
    {
        public override void Cast(params GlobalTargetInfo[] targets)
        {
            Ability.MakeStaticFleck(this.pawn.DrawPos, this.pawn.Map, USH_DefOf.USH_JumpOfFaithFleck, this.def.castFleckScaleWithRadius ? this.GetRadiusForPawn() : this.def.castFleckScale, this.def.castFleckSpeed);
            var map = Caster.Map;
            var flyer = (USH_JumpingPawn)PawnFlyer.MakeFlyer(USH_DefOf.USH_JumpingPawn, CasterPawn, targets[0].Cell);
            flyer.ability = this;
            flyer.target = targets[0].Cell.ToVector3Shifted();
            GenSpawn.Spawn(flyer, Caster.Position, map);
            base.Cast(targets);
        }
    }
}