﻿namespace MatrixRimloaded
{
    using RimWorld;
    using RimWorld.Planet;
    using System.Collections.Generic;
    using System.Linq;
    using UnityEngine;
    using Verse;
    using Verse.AI;
    using VFECore.Abilities;
    using VanillaPsycastsExpanded;
    using System;

    public class Ability_Phasing : Ability_TargetCorpse
    {


        public override void Cast(params GlobalTargetInfo[] targets)
        {
            base.Cast(targets);
            foreach (var target in targets)
            {
                Corpse thing = target.Thing as Corpse;
                Resurrect(thing);
            }
        }

        public override void WarmupToil(Toil toil)
        {
            toil.WithEffect(USH_DefOf.USH_HackingBody, TargetIndex.A);
        }

        protected void Resurrect(Corpse target)
        {
            Pawn innerPawn = target.InnerPawn;
            List<Hediff> hediffs = innerPawn.health.hediffSet.hediffs;
            for (int index = hediffs.Count - 1; index >= 0; --index)
            {
                Hediff hediff = hediffs[index];
                if (hediff is Hediff_MissingPart hediffMissingPart)
                {
                    BodyPartRecord part = hediffMissingPart.Part;
                    innerPawn.health.RemoveHediff(hediff);
                    innerPawn.health.RestorePart(part);
                }
                else if (hediff.def != VPE_DefOf.TraumaSavant && (hediff.def.isBad || hediff is Hediff_Addiction) && hediff.def.everCurableByItem)
                    innerPawn.health.RemoveHediff(hediff);
            }
            ResurrectionUtility.ResurrectWithSideEffects(innerPawn);
            if (!innerPawn.Spawned)
                GenSpawn.Spawn((Thing)innerPawn, target.Position, target.Map);
        }
    }
}