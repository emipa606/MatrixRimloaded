﻿namespace MatrixRimloaded
{
    using RimWorld;
    using RimWorld.Planet;
    using Verse;
    using Verse.AI;
    using Ability = VFECore.Abilities.Ability;

    public class Ability_SkillHack : Ability
    {
        public SkillDef skillToLearn;

        public override void DoAction()
        {
            Find.WindowStack.Add((Window)new Dialog_ChooseMatrixSkill(this));
            base.DoAction();
        }

        public override void Cast(params GlobalTargetInfo[] targets)
        {
            base.Cast(targets);
            if(skillToLearn == null)
            {
                pawn.jobs.EndCurrentJob(Verse.AI.JobCondition.InterruptForced);
                Messages.Message((string)"USH_NoSkillChosen".Translate(), this.CasterPawn, MessageTypeDefOf.NeutralEvent, false);
            }
            foreach (var target in targets)
            {
                Pawn targetP = target.Thing as Pawn;
                targetP.skills.GetSkill(skillToLearn).Learn(35000f, true);
            }
        }

        public override void WarmupToil(Toil toil)
        {
            toil.WithEffect(() => USH_DefOf.USH_HackingBody, () => this.firstTarget.Pawn.OccupiedRect().ClosestCellTo(this.CasterPawn.Position));
        }
    }
}