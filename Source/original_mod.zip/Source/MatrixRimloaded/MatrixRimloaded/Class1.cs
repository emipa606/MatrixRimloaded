﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Verse;
using RimWorld;

namespace MatrixRimloaded
{
    public class ImplosionExpanding : Thing
    {
        public override void PostMake()
        {
            base.PostMake();
            Mote distortion = (Mote)ThingMaker.MakeThing(ThingDef.Named("DistortionBubble"));
            GenSpawn.Spawn(distortion, this.Position, this.Map);
            this.Destroy(DestroyMode.Vanish);
        }
    }
}
