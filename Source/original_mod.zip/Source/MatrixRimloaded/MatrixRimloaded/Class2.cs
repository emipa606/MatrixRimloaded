﻿using RimWorld.Planet;
using System.Collections.Generic;
using Verse;
using VFECore.Abilities;

namespace MatrixRimloaded
{
    public class Ability_Implode : Ability
    {
        public override void Cast(params GlobalTargetInfo[] targets)
        {
            base.Cast(targets);
            foreach (GlobalTargetInfo target in targets)
            {
                Thing implosion = (Thing)ThingMaker.MakeThing(ThingDef.Named("USH_ImplosionExpanding"));
                GenSpawn.Spawn(implosion, target.Cell, pawn.Map);
                //GenExplosion.DoExplosion(center, map, (float)explosionRadius, explosionDamageDef, (Thing)pawn, explosionDamageAmount, (float)armorPenetration, explosionSound, postExplosionSpawnThingDef: explosionSpawnThingDef1, postExplosionSpawnChance: ((float)explosionSpawnChance1), postExplosionSpawnThingCount: explosionSpawnThingCount1, applyDamageToExplosionCellsNeighbors: (num1 != 0), preExplosionSpawnThingDef: explosionSpawnThingDef2, preExplosionSpawnChance: ((float)explosionSpawnChance2), preExplosionSpawnThingCount: explosionSpawnThingCount2, chanceToStartFire: ((float)chanceToStartFire), damageFalloff: (num2 != 0), direction: explosionDirection, ignoredThings: ignoredThings);
            }
        }
    }
}
