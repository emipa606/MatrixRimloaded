﻿using System;
using System.Linq;
using UnityEngine;
using Verse;
using Verse.Sound;
using RimWorld;

namespace MatrixRimloaded
{
    public class Dialog_ChooseMatrixSkill : Window
    {
        private Ability_SkillHack skillHack;
        private Vector2 scrollPosition;
        private bool skillWasChosen = false;

        public override Vector2 InitialSize => new Vector2(200f, 500f);

        public Dialog_ChooseMatrixSkill(Ability_SkillHack skillHack)
        {
            this.skillHack = skillHack;
            this.doCloseButton = false;
            this.forcePause = true;
            this.doCloseX = false;
            this.closeOnClickedOutside = true;
            this.absorbInputAroundWindow = true;
            
        }

        public override void DoWindowContents(Rect inRect)
        {
            Text.Font = GameFont.Small;
            Rect outRect = new Rect(inRect);
            outRect.yMin += 20f;
            outRect.yMax -= 40f;
            outRect.width -= 16f;
            Rect viewRect = new Rect(0.0f, 0.0f, outRect.width + 128f, (float)((double)DefDatabase<SkillDef>.AllDefs.Count() * 35.0 + 100.0));
            Widgets.BeginScrollView(outRect, ref this.scrollPosition, viewRect, false);
            try
            {
                float y = 0.0f;
                
                bool flag = false;
                foreach (SkillDef skill in DefDatabase<SkillDef>.AllDefs)
                {
                    flag = true;
                    Rect rect = new Rect(0.0f, y, viewRect.width * 0.7f, 32f);
                    rect.x = outRect.center.x - 63f;
                    rect.width = viewRect.width * 0.5f;
                    if (Widgets.ButtonText(rect, skill.defName))
                    {
                        skillWasChosen = true;
                        skillHack.skillToLearn = skill;
                        SoundDefOf.Click.PlayOneShotOnCamera();
                        this.Close();
                        return;
                    }
                    y += 35f;
                }
                if (flag)
                    y += 15f;
            }
            finally
            {
                Widgets.EndScrollView();
            }
        }

        public override void PostClose()
        {
            if (!skillWasChosen)
            {
                //End targeting. But how?
            }
            base.PostClose();
        }
    }
}
