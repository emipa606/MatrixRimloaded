﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Verse;
using HarmonyLib;
using RimWorld;
using System.Reflection;

namespace MatrixRimloaded.Patch
{

    [StaticConstructorOnStartup]
    public static class MatrixRimloaded
    {
        static MatrixRimloaded()
        {
            Log.Message("Matrix rimloading... loaded.");

            Harmony harmony = new Harmony("rimworld.mod.ushankas.matrix");
            harmony.PatchAll();
        }
    }

    [HarmonyPatch]
    public static class Projectile_Patch
    {
        [HarmonyPatch(typeof(Projectile), "CanHit")]
        [HarmonyPrefix]
        public static bool CanHit_Prefix(Bullet __instance)
        {
            if (__instance.intendedTarget != null && __instance != null)
            {
                if (__instance.intendedTarget.Pawn != null)
                {
                    if (__instance.intendedTarget.Pawn.health.hediffSet.HasHediff(USH_DefOf.USH_BulletDodge))
                        return false;
                    else
                        return true;
                }
                else
                    return true;

            } else
            {
                return true;
            }
        }
    }
}
