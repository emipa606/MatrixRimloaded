﻿using System.Collections.Generic;
using System.Linq;
using RimWorld;
using UnityEngine;
using UnityEngine.UIElements;
using Verse;
using Verse.Sound;
using VFECore;
using VFECore.Abilities;

namespace MatrixRimloaded
{

    public class USH_JumpingPawn : AbilityPawnFlyer
    {
        public override void DrawAt(Vector3 drawLoc, bool flip = false)
        {
            FlyingPawn.DrawAt(GetDrawPos(), flip);
        }

        private Vector3 GetDrawPos()
        {
            var x = ticksFlying / (float)ticksFlightTime;
            var drawPos = position;
            drawPos.y = AltitudeLayer.Skyfaller.AltitudeFor();
            return drawPos + Vector3.forward * (x - Mathf.Pow(x, 2)) * 15f;
        }
        protected override void RespawnPawn()
        {
            Pawn flyingPawn = FlyingPawn;
            base.RespawnPawn();
            USH_DefOf.USH_JumpOfFaith_Land.PlayOneShot(flyingPawn);
            FleckMaker.ThrowSmoke(flyingPawn.DrawPos, flyingPawn.Map, 1f);
            FleckMaker.ThrowDustPuffThick(flyingPawn.DrawPos, flyingPawn.Map, 2f, new Color(1f, 1f, 1f, 2.5f));
        }
    }
}